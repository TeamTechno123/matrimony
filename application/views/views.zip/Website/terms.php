<?php include("header.php"); ?>
<section class="policy">
  <div class="container">
    <div class="row">
      <h1>Terms & Condition</h1>
      <p>Company Name: BHARTIYA SHADI DOT COM is sole proprietorship company. founded by Mr.Deepak Yashwant Parole in 06 march 2019. BHARTIYA SHADI DOT COM has been established as a Online matrimony service , Advertising service , Business Service provider & Social networking company, in India.</p>
      <p>Business Address: SaraswatiComplex,2nd floor office no 12 ,Rajarampuri 10th lane , main road ,Dist. . Kolhapur , State Maharashtra Country India-  Pin 416008</p>
      <p>Email: bhartiyashadi.com@gmail.com</p>
      <p>Web.www.bhartiyashadi.com </p>
      <p>Tel: 8624882140 ,</p>
      <p>Primary Information of Business: Company is online Social Media Marketing Company and working in , Matrimony Service, Online Business Services ,Online Advertising Service , Online Educations Service , online treading & marketing service and more .</p>
    </div>
  </div>
</section>

<?php include("footer.php"); ?>
