<?php include("header.php"); ?>
<section class="heading">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="text-center">User Pack</h1>
      </div>
    </div>
  </div>
</section>


<section class="profile-page" id="pack-page">
  <div class="container-fluid">
    <div class="row">
       <div class="col-md-3">
         <div class="pack-cart ">
           <div class="card radius-20" style="width: 100%;">
             <div class="card-body">
               <h5 class="card-title">Gold Pack</h5>
               <h6 class="card-subtitle mb-2 text-muted">3 Months </h6>
               <h5 class="card-title">Rs 750/ Mo</h5>
                <button type="button" class="btn btn-outline-danger mt-3">Continue</button>
               <ul class="list-group list-group-flush">
                  <li class="list-group-item" >Send Unlimited SMS</li>
                  <li class="list-group-item" style="text-decoration: line-through;">View Upto 75 Contact</li>
                  <li class="list-group-item" style="text-decoration: line-through;">Standout From Other Profile</li>
                </ul>

             </div>
            </div>
         </div>
       </div>

       <div class="col-md-3">
         <div class="pack-cart">
           <div class="card radius-20" style="width: 100%;">
             <div class="card-body">
               <h5 class="card-title">Gold Pack</h5>
               <h6 class="card-subtitle mb-2 text-muted">3 Months </h6>
               <h5 class="card-title">Rs 750/ Mo</h5>
                <button type="button" class="btn btn-outline-danger mt-3">Continue</button>
               <ul class="list-group list-group-flush">
                  <li class="list-group-item">Send Unlimited SMS</li>
                  <li class="list-group-item">View Upto 75 Contact</li>
                  <li class="list-group-item" style="text-decoration: line-through;">Standout From Other Profile</li>
                </ul>

             </div>
            </div>
         </div>
       </div>

       <div class="col-md-3">
         <div class="pack-cart">
           <div class="card radius-20" style="width: 100%;">
             <div class="card-body">
               <h5 class="card-title">Gold Pack</h5>
               <h6 class="card-subtitle mb-2 text-muted">3 Months </h6>
               <h5 class="card-title">Rs 750/ Mo</h5>
                <button type="button" class="btn btn-outline-danger mt-3">Continue</button>
               <ul class="list-group list-group-flush">
                  <li class="list-group-item">Send Unlimited SMS</li>
                  <li class="list-group-item">View Upto 75 Contact</li>
                  <li class="list-group-item" style="text-decoration: line-through;">Standout From Other Profile</li>
                </ul>

             </div>
            </div>
         </div>
       </div>

       <div class="col-md-3">
         <div class="pack-cart">
           <div class="card radius-20" style="width: 100%;">
             <div class="card-body">
               <h5 class="card-title">Gold Pack</h5>
               <h6 class="card-subtitle mb-2 text-muted">3 Months </h6>
               <h5 class="card-title">Rs 750/ Mo</h5>
                <button type="button" class="btn btn-outline-danger mt-3">Continue</button>
               <ul class="list-group list-group-flush">
                  <li class="list-group-item">Send Unlimited SMS</li>
                  <li class="list-group-item">View Upto 75 Contact</li>
                  <li class="list-group-item">Standout From Other Profile</li>
                </ul>

             </div>
            </div>
         </div>
       </div>
    </div>
  </div>
</section>




<?php include("footer.php"); ?>
