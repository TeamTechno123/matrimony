<?php
$mat_member_id = $this->session->userdata('mat_member_id');
$member_is_login = $this->session->userdata('member_is_login');
?>
<footer>
<div class="container">
  <div class="row">
    <div class="col-md-4">
      <h4>Help</h4>
        <ul class="ul-m" style="list-style-type:none">
          <li> <a href="#">Terms & Condition</a> </li>
          <li> <a href="#">Our Mission</a> </li>
          <li> <a href="#">Our Strategy</a> </li>
          <li><a href="#">CC</a> </li>
        </ul>
    </div>
    <div class="col-md-4">
      <h4>Our Location</h4>
      <p>Saraswati Complex, Rajarampuri 10th lane, main road, Dist. : Kolhapur, State : Maharashtra Country : India . Pin 416008</p>
<p>Mobile : 8624882140</p>
<!-- <p>2020 | All Rights Reserved </p> -->
    </div>

    <div class="col-md-4">
      <h4>Usefull links</h4>
      <ul class="ul-m" style="list-style-type:none">
        <li> <a href="<?php echo base_url(); ?>User">Franchising Login</a> </li>
        <li><a href="<?php echo base_url(); ?>Member/active_members">Active Members</a></li>
        <!-- <li> <a href="<?php echo base_url(); ?>Website/profile">Profile</a> </li>
        <li><a href="<?php echo base_url(); ?>Website/active_members">Active Members</a></li> -->
        <li> <a href="<?php echo base_url(); ?>Website">Sign In</a> </li>
        <li> <a href="<?php echo base_url(); ?>Website/terms">Terms And Conditions</a> </li>
        <li><a href="<?php echo base_url(); ?>Website/policy">Policy</a> </li>
      </ul>
    </div>
  </div>
  <div class="bottom">
    <p>Design & Develope By <a href="#">Techno Thinks Up Solution Pvt. Ltd </a> </p>
  </div>
</div>
</footer>



    <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="<?php echo base_url(); ?>assets/css/owl.carousel.js"></script>

    <script src="<?php echo base_url(); ?>assets/plugins/select2/js/select2.full.min.js"></script>
    <!-- daterangepicker -->
    <script src="<?php echo base_url(); ?>assets/plugins/moment/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/daterangepicker/daterangepicker.js"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <script src="<?php echo base_url(); ?>assets/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>

    <script type="text/javascript">
      $('#date1').datetimepicker({
        format: 'DD-MM-Y'
      });
      $('#date2').datetimepicker({
        format: 'DD-MM-Y'
      });
      $('#date3').datetimepicker({
        format: 'DD-MM-Y'
      })
      $('#date4').datetimepicker({
        format: 'DD-MM-Y'
      })
      $('#date5').datetimepicker({
        format: 'DD-MM-Y'
      })
    </script>
    <script>
      $(function () {
        // Initialize Select2 Elements
        $('.select2bs4').select2({
          theme: 'bootstrap4'
        });
        //Initialize Select2 Elements
        $('.select2').select2();
      })
    </script>
    <script src="<?php echo base_url(); ?>assets/js/validation.js"></script>



  </body>
</html>
